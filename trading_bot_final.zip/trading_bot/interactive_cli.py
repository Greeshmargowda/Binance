#!/usr/bin/env python3
"""
interactive_cli.py — Enhanced menu-driven CLI for the Binance Futures Testnet bot.

Run with:
    python interactive_cli.py
or with pre-loaded credentials:
    BINANCE_API_KEY=xxx BINANCE_API_SECRET=yyy python interactive_cli.py
"""

from __future__ import annotations

import os
import sys
import textwrap
from decimal import Decimal
from typing import Callable, Optional, Tuple

from bot.advanced_orders import (
    place_grid_order,
    place_oco_order,
    place_stop_limit_order,
    place_twap_order,
)
from bot.client import BinanceClient, BinanceClientError
from bot.credentials import (
    clear_credentials,
    credentials_exist,
    credentials_source,
    load_credentials,
    save_credentials,
)
from bot.logging_config import setup_logger
from bot.orders import place_limit_order, place_market_order, place_stop_market_order
from bot.validators import (
    validate_order_type,
    validate_price,
    validate_quantity,
    validate_side,
    validate_stop_price,
    validate_symbol,
)

logger = setup_logger("interactive_cli")

# ---------------------------------------------------------------------------
# ANSI colour helpers
# ---------------------------------------------------------------------------

RESET  = "\033[0m"
BOLD   = "\033[1m"
DIM    = "\033[2m"
GREEN  = "\033[32m"
YELLOW = "\033[33m"
CYAN   = "\033[36m"
RED    = "\033[31m"
WHITE  = "\033[97m"
BG_DARK = "\033[48;5;234m"


def c(text: str, *codes: str) -> str:
    return "".join(codes) + text + RESET


def header() -> None:
    os.system("clear" if os.name != "nt" else "cls")
    print(c("╔══════════════════════════════════════════════════╗", BOLD, CYAN))
    print(c("║   ⬡  BINANCE FUTURES TESTNET  ·  TRADING BOT  ⬡  ║", BOLD, CYAN))
    print(c("╚══════════════════════════════════════════════════╝", BOLD, CYAN))
    print()


def divider() -> None:
    print(c("  " + "─" * 48, DIM))


def ok(msg: str) -> None:
    print(c(f"  ✔  {msg}", GREEN, BOLD))


def err(msg: str) -> None:
    print(c(f"  ✗  {msg}", RED, BOLD))


def warn(msg: str) -> None:
    print(c(f"  ⚠  {msg}", YELLOW))


def info(msg: str) -> None:
    print(c(f"  ·  {msg}", CYAN))


# ---------------------------------------------------------------------------
# Prompt helpers with inline validation
# ---------------------------------------------------------------------------


def prompt(
    label: str,
    validator: Optional[Callable] = None,
    default: Optional[str] = None,
    hint: str = "",
    secret: bool = False,
) -> str:
    """
    Prompt the user for input, re-prompting on validation failure.
    Returns the validated (and possibly transformed) value as a string.
    """
    display_default = f" [{c(str(default), DIM)}]" if default is not None else ""
    display_hint    = f"  {c(hint, DIM)}" if hint else ""

    while True:
        try:
            if secret:
                import getpass
                raw = getpass.getpass(
                    prompt=c(f"  {label}{display_default}: ", BOLD, WHITE)
                ).strip()
            else:
                raw = input(
                    c(f"  {label}{display_default}{display_hint}: ", BOLD, WHITE)
                ).strip()
        except (KeyboardInterrupt, EOFError):
            print()
            raise

        if raw == "" and default is not None:
            raw = str(default)

        if not raw:
            err(f"{label} cannot be empty.")
            continue

        if validator:
            try:
                result = validator(raw)
                # validator may return a transformed value (e.g. Decimal)
                return str(result) if not isinstance(result, str) else result
            except ValueError as e:
                err(str(e))
        else:
            return raw


def prompt_choice(label: str, choices: list[Tuple[str, str]]) -> str:
    """
    Display a numbered menu and return the key of the chosen option.
    `choices` is a list of (key, description) tuples.
    """
    print()
    print(c(f"  {label}", BOLD, WHITE))
    divider()
    for i, (key, desc) in enumerate(choices, 1):
        print(f"  {c(str(i), BOLD, CYAN)}.  {c(key, BOLD)}  {c('·', DIM)}  {c(desc, DIM)}")
    divider()

    while True:
        try:
            raw = input(c("  Select › ", BOLD, YELLOW)).strip()
        except (KeyboardInterrupt, EOFError):
            print()
            raise

        if raw.isdigit():
            idx = int(raw) - 1
            if 0 <= idx < len(choices):
                chosen = choices[idx][0]
                ok(f"Selected: {chosen}")
                return chosen
        # also accept typing the key directly
        for key, _ in choices:
            if raw.upper() == key.upper():
                ok(f"Selected: {key}")
                return key
        err(f"Please enter a number between 1 and {len(choices)}.")


def confirm(label: str = "Confirm and submit order?") -> bool:
    """Ask for yes/no confirmation."""
    print()
    try:
        raw = input(c(f"  {label} [y/N] › ", BOLD, YELLOW)).strip().lower()
    except (KeyboardInterrupt, EOFError):
        return False
    return raw in ("y", "yes")


# ---------------------------------------------------------------------------
# Credentials screen
# ---------------------------------------------------------------------------


def get_credentials() -> Tuple[str, str]:
    """
    Load credentials using priority: env vars → saved file → prompt.
    If prompted, offer to save for next time.
    """
    header()
    print(c("  CREDENTIALS", BOLD, YELLOW))
    divider()

    api_key, api_secret = load_credentials()
    source = credentials_source()

    if api_key and api_secret:
        ok(f"Credentials loaded from {source}.")
        return api_key, api_secret

    # Nothing saved — prompt user
    info("No saved credentials found.")
    info("Enter your Binance Futures Testnet API key and secret.")
    print()
    api_key    = prompt("API Key",    hint="from testnet.binancefuture.com")
    api_secret = prompt("API Secret", secret=True)

    # Offer to save
    print()
    try:
        ans = input(c("  Save credentials for future sessions? [Y/n] › ", BOLD, YELLOW)).strip().lower()
    except (KeyboardInterrupt, EOFError):
        ans = "n"

    if ans in ("", "y", "yes"):
        save_credentials(api_key, api_secret)
        ok("Credentials saved to ~/.trading_bot/credentials.json")
    else:
        warn("Credentials NOT saved — you will be prompted again next time.")

    return api_key, api_secret


def manage_credentials_menu(client_ref: list) -> None:
    """Settings sub-menu for credential management."""
    header()
    print(c("  CREDENTIAL SETTINGS", BOLD, YELLOW))
    divider()
    info(f"Current source: {credentials_source()}")
    print()

    choice = prompt_choice("What would you like to do?", [
        ("VIEW",   "Show credential source (key never printed)"),
        ("UPDATE",  "Enter new API key + secret and save"),
        ("CLEAR",  "Delete saved credentials from disk"),
        ("BACK",   "Return to main menu"),
    ])

    if choice == "VIEW":
        info(f"Source: {credentials_source()}")
        if credentials_exist():
            info("File:   ~/.trading_bot/credentials.json")

    elif choice == "UPDATE":
        new_key    = prompt("New API Key",    hint="from testnet.binancefuture.com")
        new_secret = prompt("New API Secret", secret=True)
        save_credentials(new_key, new_secret)
        ok("Credentials updated and saved.")
        # Rebuild client with new creds
        client_ref[0] = BinanceClient(new_key, new_secret)
        ok("Client reconnected with new credentials.")

    elif choice == "CLEAR":
        try:
            ans = input(c("  Really delete saved credentials? [y/N] › ", BOLD, YELLOW)).strip().lower()
        except (KeyboardInterrupt, EOFError):
            ans = "n"
        if ans in ("y", "yes"):
            if clear_credentials():
                ok("Saved credentials deleted.")
            else:
                warn("No saved credentials found on disk.")
        else:
            warn("Cancelled.")


# ---------------------------------------------------------------------------
# Per-order-type flows
# ---------------------------------------------------------------------------


def flow_market(client: BinanceClient) -> None:
    print(c("\n  MARKET ORDER", BOLD, CYAN))
    divider()
    symbol = prompt("Symbol",   validator=validate_symbol, hint="e.g. BTCUSDT")
    side   = prompt_choice("Side", [("BUY", "Buy / long"), ("SELL", "Sell / short")])
    qty    = prompt("Quantity", validator=validate_quantity, hint="base asset amount")

    print()
    info(f"Will place MARKET {side} {qty} {symbol}")
    if not confirm():
        warn("Order cancelled.")
        return

    place_market_order(client, symbol, side, Decimal(qty))


def flow_limit(client: BinanceClient) -> None:
    print(c("\n  LIMIT ORDER", BOLD, CYAN))
    divider()
    symbol = prompt("Symbol",      validator=validate_symbol, hint="e.g. BTCUSDT")
    side   = prompt_choice("Side", [("BUY", "Buy / long"), ("SELL", "Sell / short")])
    qty    = prompt("Quantity",    validator=validate_quantity)
    price  = prompt("Limit Price", validator=lambda v: validate_price(v, "LIMIT"))
    tif    = prompt_choice("Time-in-Force", [
        ("GTC", "Good Till Cancelled"),
        ("IOC", "Immediate or Cancel"),
        ("FOK", "Fill or Kill"),
    ])

    info(f"Will place LIMIT {side} {qty} {symbol} @ {price} ({tif})")
    if not confirm():
        warn("Order cancelled.")
        return

    place_limit_order(client, symbol, side, Decimal(qty), Decimal(price), tif)


def flow_stop_market(client: BinanceClient) -> None:
    print(c("\n  STOP-MARKET ORDER", BOLD, CYAN))
    divider()
    symbol     = prompt("Symbol",      validator=validate_symbol)
    side       = prompt_choice("Side", [("BUY", "Buy on stop trigger"), ("SELL", "Sell on stop trigger")])
    qty        = prompt("Quantity",    validator=validate_quantity)
    stop_price = prompt("Stop Price",  validator=lambda v: validate_stop_price(v, "STOP_MARKET"),
                        hint="trigger price")

    info(f"Will place STOP_MARKET {side} {qty} {symbol}  trigger @ {stop_price}")
    if not confirm():
        warn("Order cancelled.")
        return

    place_stop_market_order(client, symbol, side, Decimal(qty), Decimal(stop_price))


def flow_stop_limit(client: BinanceClient) -> None:
    print(c("\n  STOP-LIMIT ORDER", BOLD, CYAN))
    divider()
    info("Triggered at stop price, then placed as a limit order at limit price.")
    print()
    symbol     = prompt("Symbol",      validator=validate_symbol)
    side       = prompt_choice("Side", [("BUY", "Buy on trigger"), ("SELL", "Sell on trigger")])
    qty        = prompt("Quantity",    validator=validate_quantity)
    stop_price = prompt("Stop Price",  validator=validate_quantity, hint="trigger price")
    lim_price  = prompt("Limit Price", validator=validate_quantity, hint="fill price after trigger")
    tif        = prompt_choice("Time-in-Force", [("GTC","Good Till Cancelled"), ("IOC","Immediate or Cancel")])

    info(f"Will place STOP-LIMIT {side} {qty} {symbol}  stop={stop_price}  limit={lim_price}")
    if not confirm():
        warn("Order cancelled.")
        return

    place_stop_limit_order(client, symbol, side, Decimal(qty), Decimal(lim_price), Decimal(stop_price), tif)


def flow_oco(client: BinanceClient) -> None:
    print(c("\n  OCO ORDER  (One-Cancels-the-Other)", BOLD, CYAN))
    divider()
    info("Places a take-profit LIMIT + a stop STOP-LIMIT simultaneously.")
    info("Filling one automatically cancels the other.")
    print()
    symbol         = prompt("Symbol",           validator=validate_symbol)
    side           = prompt_choice("Side",       [("BUY","Buy OCO"), ("SELL","Sell OCO")])
    qty            = prompt("Quantity",          validator=validate_quantity)
    tp_price       = prompt("Take-Profit Price", validator=validate_quantity)
    stop_trig      = prompt("Stop Trigger",      validator=validate_quantity, hint="stop trigger price")
    stop_lim       = prompt("Stop Limit Price",  validator=validate_quantity, hint="stop fill price")

    info(f"OCO {side} {qty} {symbol}  TP={tp_price}  stop={stop_trig}  stop-limit={stop_lim}")
    if not confirm():
        warn("Order cancelled.")
        return

    place_oco_order(client, symbol, side, Decimal(qty), Decimal(tp_price), Decimal(stop_trig), Decimal(stop_lim))


def flow_twap(client: BinanceClient) -> None:
    print(c("\n  TWAP ORDER  (Time-Weighted Average Price)", BOLD, CYAN))
    divider()
    info("Splits a large order into equal slices placed at regular intervals.")
    print()
    symbol   = prompt("Symbol",      validator=validate_symbol)
    side     = prompt_choice("Side", [("BUY","Buy TWAP"), ("SELL","Sell TWAP")])
    total    = prompt("Total Quantity", validator=validate_quantity)
    slices   = prompt("Number of Slices", validator=lambda v: str(int(v)) if int(v) >= 2 else (_ for _ in ()).throw(ValueError("Need ≥ 2 slices")), default="5")
    interval = prompt("Interval (seconds)", validator=lambda v: str(int(v)) if int(v) >= 1 else (_ for _ in ()).throw(ValueError("Need ≥ 1 second")), default="10")
    child_type = prompt_choice("Child Order Type", [("MARKET","Market per slice"), ("LIMIT","Limit per slice")])

    price = None
    if child_type == "LIMIT":
        price = prompt("Limit Price", validator=validate_quantity)

    est = (int(slices) - 1) * int(interval)
    info(f"TWAP: {total} {symbol} in {slices} slices every {interval}s  (~{est}s total)")
    warn("The terminal will block while TWAP runs. Do not close it.")
    if not confirm():
        warn("Order cancelled.")
        return

    place_twap_order(
        client, symbol, side, Decimal(total),
        int(slices), int(interval),
        child_type, Decimal(price) if price else None,
    )


def flow_grid(client: BinanceClient) -> None:
    print(c("\n  GRID ORDER", BOLD, CYAN))
    divider()
    info("Places multiple LIMIT orders at evenly-spaced price levels.")
    info("BUY grid steps DOWN; SELL grid steps UP.")
    print()
    symbol   = prompt("Symbol",           validator=validate_symbol)
    side     = prompt_choice("Side",       [("BUY","Buy grid (DCA down)"), ("SELL","Sell grid (distribute up)")])
    levels   = prompt("Number of Levels", validator=lambda v: str(int(v)) if int(v) >= 2 else (_ for _ in ()).throw(ValueError("Need ≥ 2 levels")), default="5")
    qty_each = prompt("Quantity per Level",validator=validate_quantity)
    start    = prompt("Start Price",       validator=validate_quantity, hint="first grid level")
    step     = prompt("Step (price gap)",  validator=validate_quantity, hint="spacing between levels")

    total_qty = Decimal(qty_each) * int(levels)
    info(f"Grid: {levels} levels  ×  {qty_each} {symbol}  =  {total_qty} total  start={start}  step={step}")
    if not confirm():
        warn("Order cancelled.")
        return

    place_grid_order(client, symbol, side, Decimal(qty_each), int(levels), Decimal(start), Decimal(step))


# ---------------------------------------------------------------------------
# Main menu loop
# ---------------------------------------------------------------------------

ORDER_FLOWS = {
    "MARKET":      ("Standard market order (instant fill)", flow_market),
    "LIMIT":       ("Limit order at a specific price",      flow_limit),
    "STOP_MARKET": ("Market order triggered at stop price", flow_stop_market),
    "STOP_LIMIT":  ("Limit order triggered at stop price",  flow_stop_limit),
    "OCO":         ("One-Cancels-the-Other (TP + Stop-Limit)", flow_oco),
    "TWAP":        ("Split large order over time",          flow_twap),
    "GRID":        ("Multiple levels at spaced prices",     flow_grid),
}


def main() -> None:
    try:
        api_key, api_secret = get_credentials()
    except (KeyboardInterrupt, EOFError):
        print("\n  Bye!")
        sys.exit(0)

    client = BinanceClient(api_key, api_secret)

    # Quick connectivity check
    try:
        client.get_server_time()
        ok("Connected to Binance Futures Testnet.\n")
    except Exception as exc:
        err(f"Could not reach testnet: {exc}")
        err("Check your internet connection and API credentials.")
        sys.exit(1)

    while True:
        header()
        try:
            order_type = prompt_choice(
                "Select Order Type",
                [(k, v[0]) for k, v in ORDER_FLOWS.items()]
                + [("EXIT", "Quit the bot")],
            )
        except (KeyboardInterrupt, EOFError):
            break

        if order_type == "EXIT":
            break

        print()
        _, flow_fn = ORDER_FLOWS[order_type]
        try:
            flow_fn(client)
        except BinanceClientError as exc:
            err(f"API error {exc.code}: {exc.message}")
            logger.error("Order failed: %s", exc)
        except (KeyboardInterrupt, EOFError):
            warn("Interrupted — returning to menu.")
        except Exception as exc:
            err(f"Unexpected error: {exc}")
            logger.exception("Unexpected error in flow")

        print()
        try:
            input(c("  Press Enter to return to the menu…", DIM))
        except (KeyboardInterrupt, EOFError):
            break

    print(c("\n  Thanks for trading! Goodbye.\n", BOLD, CYAN))


if __name__ == "__main__":
    main()
