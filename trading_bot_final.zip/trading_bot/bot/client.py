"""
Low-level Binance Futures Testnet REST client.

Handles:
  - HMAC-SHA256 request signing
  - Timestamp synchronisation
  - HTTP requests with timeout & retry
  - Structured logging of every request/response
"""

from __future__ import annotations

import hashlib
import hmac
import time
from typing import Any, Dict, Optional
from urllib.parse import urlencode

import requests
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry

from bot.logging_config import setup_logger

BASE_URL = "https://testnet.binancefuture.com"
RECV_WINDOW = 5000  # ms


class BinanceClientError(Exception):
    """Raised when the Binance API returns an error response."""

    def __init__(self, code: int, message: str) -> None:
        self.code = code
        self.message = message
        super().__init__(f"Binance API error {code}: {message}")


class BinanceClient:
    """
    Thin wrapper around the Binance Futures Testnet REST API.

    All signed endpoints automatically attach a timestamp and HMAC
    signature.  Responses are logged at DEBUG level; errors at ERROR.
    """

    def __init__(self, api_key: str, api_secret: str, log_dir: str = "logs") -> None:
        self._api_key = api_key
        self._api_secret = api_secret.encode()
        self.logger = setup_logger("binance_client", log_dir)

        # Session with retry logic (network-level failures)
        self._session = requests.Session()
        retry = Retry(
            total=3,
            backoff_factor=0.5,
            status_forcelist=[429, 500, 502, 503, 504],
        )
        adapter = HTTPAdapter(max_retries=retry)
        self._session.mount("https://", adapter)
        self._session.headers.update({"X-MBX-APIKEY": self._api_key})

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _sign(self, params: Dict[str, Any]) -> Dict[str, Any]:
        """Append timestamp + HMAC-SHA256 signature to params dict."""
        params["timestamp"] = int(time.time() * 1000)
        params["recvWindow"] = RECV_WINDOW
        query = urlencode(params)
        sig = hmac.new(self._api_secret, query.encode(), hashlib.sha256).hexdigest()
        params["signature"] = sig
        return params

    def _request(
        self,
        method: str,
        path: str,
        params: Optional[Dict[str, Any]] = None,
        signed: bool = True,
    ) -> Dict[str, Any]:
        """
        Execute an HTTP request, log it, and return the parsed JSON body.

        Raises:
            BinanceClientError: On non-2xx API responses with a JSON error body.
            requests.RequestException: On network / timeout failures.
        """
        params = params or {}
        if signed:
            params = self._sign(params)

        url = BASE_URL + path
        self.logger.debug("REQUEST  %s %s  params=%s", method.upper(), url, params)

        resp = self._session.request(method, url, params=params, timeout=10)

        self.logger.debug(
            "RESPONSE %s %s  status=%d  body=%s",
            method.upper(),
            url,
            resp.status_code,
            resp.text[:2000],  # truncate very long bodies
        )

        data = resp.json()

        # Binance returns errors as {"code": <negative int>, "msg": "..."}
        if isinstance(data, dict) and data.get("code", 0) < 0:
            self.logger.error(
                "API error — code=%s  msg=%s", data.get("code"), data.get("msg")
            )
            raise BinanceClientError(data["code"], data.get("msg", "Unknown error"))

        if not resp.ok:
            self.logger.error("HTTP error %d: %s", resp.status_code, resp.text)
            resp.raise_for_status()

        return data

    # ------------------------------------------------------------------
    # Public API methods
    # ------------------------------------------------------------------

    def get_server_time(self) -> int:
        """Return Binance server time in milliseconds (unauthenticated)."""
        data = self._request("GET", "/fapi/v1/time", signed=False)
        return data["serverTime"]

    def get_account(self) -> Dict[str, Any]:
        """Return futures account information."""
        return self._request("GET", "/fapi/v2/account")

    def get_exchange_info(self, symbol: Optional[str] = None) -> Dict[str, Any]:
        """Return exchange info, optionally filtered to a single symbol."""
        params: Dict[str, Any] = {}
        if symbol:
            params["symbol"] = symbol
        return self._request("GET", "/fapi/v1/exchangeInfo", params=params, signed=False)

    def place_order(self, **kwargs: Any) -> Dict[str, Any]:
        """
        Place a new order.

        Keyword args mirror the Binance /fapi/v1/order POST parameters,
        e.g. symbol, side, type, quantity, price, timeInForce, stopPrice.
        """
        return self._request("POST", "/fapi/v1/order", params=kwargs)

    def get_order(self, symbol: str, order_id: int) -> Dict[str, Any]:
        """Query a specific order by orderId."""
        return self._request("GET", "/fapi/v1/order", params={"symbol": symbol, "orderId": order_id})

    def place_order_raw(self, method: str, path: str, params: Dict[str, Any]) -> Dict[str, Any]:
        """Send a signed request to an arbitrary order endpoint (e.g. OCO)."""
        return self._request(method, path, params=params)

    def cancel_order(self, symbol: str, order_id: int) -> Dict[str, Any]:
        """Cancel an open order."""
        return self._request(
            "DELETE", "/fapi/v1/order", params={"symbol": symbol, "orderId": order_id}
        )
